import {
  boolean,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  bigint,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  username: varchar("username", { length: 64 }),
  avatarUrl: text("avatarUrl"),
  language: varchar("language", { length: 8 }).default("pt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  lastLoginIp: varchar("lastLoginIp", { length: 45 }),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── VIP Users ────────────────────────────────────────────────────────────────
export const vipUsers = mysqlTable("vip_users", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  vipLevel: mysqlEnum("vipLevel", ["vip1", "vip2", "vip3", "vip4"]).notNull().default("vip1"),
  keyLimit: int("keyLimit").notNull().default(200),
  dailyLimit: int("dailyLimit").notNull().default(1000),
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type VipUser = typeof vipUsers.$inferSelect;
export type InsertVipUser = typeof vipUsers.$inferInsert;

// ─── Packages ─────────────────────────────────────────────────────────────────
export const packages = mysqlTable("packages", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  name: varchar("name", { length: 128 }).notNull(),
  version: varchar("version", { length: 32 }).default("1.0.0").notNull(),
  description: text("description"),
  token: varchar("token", { length: 128 }).notNull().unique(),
  status: mysqlEnum("status", ["active", "paused", "updating", "deleted"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Package = typeof packages.$inferSelect;
export type InsertPackage = typeof packages.$inferInsert;

// ─── Keys ─────────────────────────────────────────────────────────────────────
export const keys = mysqlTable("keys", {
  id: int("id").autoincrement().primaryKey(),
  packageId: int("packageId").notNull(),
  ownerId: int("ownerId").notNull(),
  keyValue: varchar("keyValue", { length: 256 }).notNull().unique(),
  alias: varchar("alias", { length: 64 }),
  duration: mysqlEnum("duration", ["day", "week", "month", "year"]).notNull().default("month"),
  status: mysqlEnum("status", ["active", "inactive", "expired", "revoked", "paused"]).default("inactive").notNull(),
  activatedAt: timestamp("activatedAt"),
  expiresAt: timestamp("expiresAt"),
  deviceId: int("deviceId"),
  note: text("note"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Key = typeof keys.$inferSelect;
export type InsertKey = typeof keys.$inferInsert;

// ─── Devices ──────────────────────────────────────────────────────────────────
export const devices = mysqlTable("devices", {
  id: int("id").autoincrement().primaryKey(),
  udid: varchar("udid", { length: 128 }).notNull().unique(),
  name: varchar("name", { length: 128 }),
  userId: int("userId"),
  packageId: int("packageId"),
  status: mysqlEnum("status", ["online", "offline", "banned"]).default("offline").notNull(),
  lastSeen: timestamp("lastSeen"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Device = typeof devices.$inferSelect;
export type InsertDevice = typeof devices.$inferInsert;

// ─── Dylib Builds ─────────────────────────────────────────────────────────────
export const dylibBuilds = mysqlTable("dylib_builds", {
  id: int("id").autoincrement().primaryKey(),
  packageId: int("packageId").notNull(),
  ownerId: int("ownerId").notNull(),
  fileName: varchar("fileName", { length: 256 }).notNull(),
  s3Url: text("s3Url").notNull(),
  s3Key: varchar("s3Key", { length: 512 }).notNull(),
  version: varchar("version", { length: 32 }).default("1.0.0").notNull(),
  sizeBytes: bigint("sizeBytes", { mode: "number" }).default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DylibBuild = typeof dylibBuilds.$inferSelect;
export type InsertDylibBuild = typeof dylibBuilds.$inferInsert;

// ─── Notifications ────────────────────────────────────────────────────────────
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["key_expiring", "new_device", "limit_reached", "package_update", "system"]).notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  message: text("message").notNull(),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ─── Activity Log ─────────────────────────────────────────────────────────────
export const activityLog = mysqlTable("activity_log", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  action: varchar("action", { length: 128 }).notNull(),
  details: text("details"),
  entityType: varchar("entityType", { length: 64 }),
  entityId: int("entityId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ActivityLog = typeof activityLog.$inferSelect;
export type InsertActivityLog = typeof activityLog.$inferInsert;

// ─── Key Aliases ──────────────────────────────────────────────────────────────
export const keyAliases = mysqlTable("key_aliases", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  alias: varchar("alias", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type KeyAlias = typeof keyAliases.$inferSelect;
export type InsertKeyAlias = typeof keyAliases.$inferInsert;
