# API Server Manager — TODO

## Schema & Database
- [x] Tabela packages (id, name, version, description, status, token, ownerId, createdAt, updatedAt)
- [x] Tabela keys (id, packageId, keyValue, alias, duration, expiresAt, activatedAt, status, deviceId, createdAt)
- [x] Tabela devices (id, udid, name, userId, packageId, status, lastSeen, createdAt)
- [x] Tabela vip_users (id, userId, vipLevel, keyLimit, dailyLimit, expiresAt, createdAt)
- [x] Tabela dylib_builds (id, packageId, fileName, s3Url, s3Key, createdAt)
- [x] Tabela notifications (id, userId, type, title, message, read, createdAt)
- [x] Tabela activity_log (id, userId, action, details, createdAt)
- [x] Estender tabela users (username, avatarUrl, language)

## Backend — tRPC Routers
- [x] Router: packages (CRUD completo + geração de token)
- [x] Router: keys (gerar, listar, revogar, estender, pausar)
- [x] Router: devices (registrar, listar, editar, remover)
- [x] Router: vipUsers (listar, promover, rebaixar, editar limites)
- [x] Router: dylib (gerar dylib simulada, upload S3, histórico)
- [x] Router: notifications (listar, marcar como lida)
- [x] Router: activityLog (registrar e listar atividades)
- [x] Router: llmDocs (gerar documentação técnica via LLM)
- [x] Router: dashboard (estatísticas gerais)
- [x] Notificações automáticas: keys expirando, novos devices, limites atingidos

## Frontend — Layout & Tema
- [x] Tema dark elegante com paleta de cores sofisticada (index.css)
- [x] DashboardLayout com sidebar navegável
- [x] Rotas configuradas em App.tsx

## Frontend — Páginas
- [x] Dashboard com cards de estatísticas e gráficos
- [x] Página de Packages (lista, criar, editar, deletar)
- [x] Página de Keys (gerar, listar, revogar, filtrar por package)
- [x] Página de Devices/UDIDs (registrar, listar, editar, remover)
- [x] Página de Usuários VIP (listar, promover, editar limites)
- [x] Página de Geração de Dylib (selecionar package, gerar, baixar, histórico)
- [x] Página de Perfil (info pessoal, histórico de uso, dispositivos logados)
- [x] Página de Notificações (listar, marcar como lida)
- [x] Página de Documentação LLM (gerar docs técnicos por package)

## Testes
- [x] Testes de packages router
- [x] Testes de keys router
- [x] Testes de devices router
- [x] Testes de notifications router
- [x] Testes de dashboard router
- [x] Testes de vipUsers router
- [x] Testes de dylib router

## Entrega
- [x] Checkpoint salvo
- [x] Sistema entregue ao usuário

## Correções de Bugs
- [x] Corrigir erro ao gerar keys (imports de Badge faltando)
- [x] Corrigir erro ao criar usuários VIP (imports de Badge faltando)
- [x] Adicionar login de teste admin/admin123 (página Login.tsx + rota testLogin)
