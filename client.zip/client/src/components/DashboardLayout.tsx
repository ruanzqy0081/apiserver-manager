import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { getLoginUrl } from "@/const";
import { useIsMobile } from "@/hooks/useMobile";
import { trpc } from "@/lib/trpc";
import {
  Bell,
  Box,
  ChevronDown,
  Cpu,
  FileCode2,
  Key,
  LayoutDashboard,
  LogOut,
  PanelLeft,
  Settings,
  Smartphone,
  User,
  Users,
  Zap,
} from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { Button } from "./ui/button";

const mainMenuItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/" },
  { icon: Box, label: "Packages", path: "/packages" },
  { icon: Key, label: "Keys", path: "/keys" },
  { icon: Smartphone, label: "Devices", path: "/devices" },
  { icon: FileCode2, label: "Build Dylib", path: "/dylib" },
  { icon: Settings, label: "Configurações", path: "/settings" },
];

const adminMenuItems = [
  { icon: Users, label: "Usuários VIP", path: "/vip-users" },
  { icon: Cpu, label: "Documentação LLM", path: "/docs" },
];

const userMenuItems = [
  { icon: User, label: "Perfil", path: "/profile" },
  { icon: Bell, label: "Notificações", path: "/notifications" },
];

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 260;
const MIN_WIDTH = 200;
const MAX_WIDTH = 400;

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  if (loading) return <DashboardLayoutSkeleton />;

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="flex flex-col items-center gap-8 p-8 max-w-md w-full">
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center glow-primary">
                <Zap className="h-6 w-6 text-primary" />
              </div>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-center gradient-text">
              IPA API Server
            </h1>
            <p className="text-sm text-muted-foreground text-center max-w-sm leading-relaxed">
              Gerencie seus packages, keys e devices com total controle. Faça login para continuar.
            </p>
            <p className="text-xs text-muted-foreground/60 text-center">
              © Ruan Dev — Todos os direitos reservados
            </p>
          </div>
          <Button
            onClick={() => { window.location.href = "/login"; }}
            size="lg"
            className="w-full glow-primary font-semibold"
          >
            Entrar no Sistema
          </Button>
        </div>
      </div>
    );
  }

  return (
    <SidebarProvider style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}>
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>
        {children}
      </DashboardLayoutContent>
    </SidebarProvider>
  );
}

function DashboardLayoutContent({
  children,
  setSidebarWidth,
}: {
  children: React.ReactNode;
  setSidebarWidth: (w: number) => void;
}) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const isAdmin = user?.role === "admin";

  const { data: unreadCount } = trpc.notifications.unreadCount.useQuery(undefined, {
    refetchInterval: 30000,
  });

  const activeLabel =
    [...mainMenuItems, ...adminMenuItems, ...userMenuItems].find((i) => i.path === location)?.label ?? "Menu";

  useEffect(() => {
    if (isCollapsed) setIsResizing(false);
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;
      const left = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newW = e.clientX - left;
      if (newW >= MIN_WIDTH && newW <= MAX_WIDTH) setSidebarWidth(newW);
    };
    const handleMouseUp = () => setIsResizing(false);
    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  const NavItem = ({ item }: { item: (typeof mainMenuItems)[0] }) => {
    const isActive = location === item.path || (item.path !== "/" && location.startsWith(item.path));
    return (
      <SidebarMenuItem>
        <SidebarMenuButton
          isActive={isActive}
          onClick={() => setLocation(item.path)}
          tooltip={item.label}
          className={`h-10 transition-all font-normal rounded-lg ${isActive ? "bg-primary/15 text-primary font-medium" : "hover:bg-accent/60"}`}
        >
          <item.icon className={`h-4 w-4 shrink-0 ${isActive ? "text-primary" : "text-muted-foreground"}`} />
          <span>{item.label}</span>
          {item.path === "/notifications" && (unreadCount ?? 0) > 0 && (
            <Badge variant="destructive" className="ml-auto h-5 min-w-5 text-xs px-1">
              {unreadCount}
            </Badge>
          )}
        </SidebarMenuButton>
      </SidebarMenuItem>
    );
  };

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar collapsible="icon" className="border-r border-sidebar-border" disableTransition={isResizing}>
          <SidebarHeader className="h-16 justify-center border-b border-sidebar-border">
            <div className="flex items-center gap-3 px-2 w-full">
              <button
                onClick={toggleSidebar}
                className="h-8 w-8 flex items-center justify-center hover:bg-accent rounded-lg transition-colors focus:outline-none shrink-0"
              >
                <PanelLeft className="h-4 w-4 text-muted-foreground" />
              </button>
              {!isCollapsed && (
                <div className="flex items-center gap-2 min-w-0">
                  <div className="h-7 w-7 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
                    <Zap className="h-4 w-4 text-primary" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-sm tracking-tight truncate gradient-text">IPA API Server</p>
                    <p className="text-[10px] text-muted-foreground truncate">Manager</p>
                  </div>
                </div>
              )}
            </div>
          </SidebarHeader>

          <SidebarContent className="gap-0 py-2">
            <SidebarGroup>
              {!isCollapsed && <SidebarGroupLabel className="text-xs text-muted-foreground/60 px-3 mb-1">Principal</SidebarGroupLabel>}
              <SidebarMenu className="px-2 gap-0.5">
                {mainMenuItems.map((item) => <NavItem key={item.path} item={item} />)}
              </SidebarMenu>
            </SidebarGroup>

            {isAdmin && (
              <SidebarGroup className="mt-2">
                {!isCollapsed && <SidebarGroupLabel className="text-xs text-muted-foreground/60 px-3 mb-1">Administração</SidebarGroupLabel>}
                <SidebarMenu className="px-2 gap-0.5">
                  {adminMenuItems.map((item) => <NavItem key={item.path} item={item} />)}
                </SidebarMenu>
              </SidebarGroup>
            )}

            <SidebarGroup className="mt-2">
              {!isCollapsed && <SidebarGroupLabel className="text-xs text-muted-foreground/60 px-3 mb-1">Conta</SidebarGroupLabel>}
              <SidebarMenu className="px-2 gap-0.5">
                {userMenuItems.map((item) => <NavItem key={item.path} item={item} />)}
              </SidebarMenu>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="p-3 border-t border-sidebar-border">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-accent/50 transition-colors w-full text-left focus:outline-none">
                  <Avatar className="h-8 w-8 border border-border shrink-0">
                    <AvatarImage src={user?.avatarUrl ?? undefined} />
                    <AvatarFallback className="text-xs font-semibold bg-primary/20 text-primary">
                      {user?.name?.charAt(0).toUpperCase() ?? "U"}
                    </AvatarFallback>
                  </Avatar>
                  {!isCollapsed && (
                    <>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate leading-none">{user?.name || "Usuário"}</p>
                        <p className="text-xs text-muted-foreground truncate mt-1">
                          {isAdmin ? "Administrador" : user?.email || ""}
                        </p>
                      </div>
                      <ChevronDown className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                    </>
                  )}
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuItem onClick={() => setLocation("/profile")}>
                  <User className="mr-2 h-4 w-4" />
                  Meu Perfil
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLocation("/notifications")}>
                  <Bell className="mr-2 h-4 w-4" />
                  Notificações
                  {(unreadCount ?? 0) > 0 && (
                    <Badge variant="destructive" className="ml-auto h-5 text-xs px-1">{unreadCount}</Badge>
                  )}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>

        <div
          className={`absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/30 transition-colors ${isCollapsed ? "hidden" : ""}`}
          onMouseDown={() => { if (!isCollapsed) setIsResizing(true); }}
          style={{ zIndex: 50 }}
        />
      </div>

      <SidebarInset>
        {isMobile && (
          <div className="flex border-b border-border h-14 items-center justify-between bg-background/95 px-3 backdrop-blur sticky top-0 z-40">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="h-9 w-9 rounded-lg" />
              <span className="font-medium text-sm">{activeLabel}</span>
            </div>
            {(unreadCount ?? 0) > 0 && (
              <button onClick={() => setLocation("/notifications")} className="relative">
                <Bell className="h-5 w-5 text-muted-foreground" />
                <span className="absolute -top-1 -right-1 h-4 w-4 bg-destructive rounded-full text-[10px] flex items-center justify-center text-white">
                  {unreadCount}
                </span>
              </button>
            )}
          </div>
        )}
        <main className="flex-1 p-5 md:p-6">{children}</main>
      </SidebarInset>
    </>
  );
}
