import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Activity, Clock, Crown, Globe, RefreshCw, Save, Shield, Smartphone, User } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export default function Profile() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const { data: vip } = trpc.vipUsers.myVip.useQuery();
  const { data: activity } = trpc.vipUsers.activity.useQuery({});
  const { data: devices } = trpc.devices.list.useQuery();
  const updateMut = trpc.vipUsers.updateProfile.useMutation({
    onSuccess: () => { utils.auth.me.invalidate(); toast.success("Perfil atualizado!"); },
  });

  const [form, setForm] = useState({ username: "", language: "pt" as "pt" | "en" });

  useEffect(() => {
    if (user) {
      setForm({
        username: (user as unknown as { username?: string }).username ?? user.name ?? "",
        language: ((user as unknown as { language?: string }).language as "pt" | "en") ?? "pt",
      });
    }
  }, [user]);

  const myDevices = devices?.filter((d) => d.userId === user?.id) ?? [];

  const actionLabels: Record<string, string> = {
    create_package: "Criou um package",
    update_package: "Atualizou um package",
    delete_package: "Deletou um package",
    generate_keys: "Gerou keys",
    activate_key: "Ativou uma key",
    revoke_key: "Revogou uma key",
    pause_key: "Pausou uma key",
    extend_key: "Estendeu uma key",
    register_device: "Registrou um device",
    generate_dylib: "Gerou uma dylib",
    update_profile: "Atualizou o perfil",
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Meu Perfil</h1>
        <p className="text-sm text-muted-foreground mt-1">Gerencie suas informações pessoais e preferências</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Card */}
        <Card className="border-border/50 bg-card/50 lg:col-span-1">
          <CardContent className="p-6 flex flex-col items-center gap-4">
            <div className="relative">
              <Avatar className="h-20 w-20 border-2 border-primary/30">
                <AvatarImage src={(user as unknown as { avatarUrl?: string })?.avatarUrl ?? undefined} />
                <AvatarFallback className="text-2xl font-bold bg-primary/20 text-primary">
                  {user?.name?.charAt(0).toUpperCase() ?? "U"}
                </AvatarFallback>
              </Avatar>
              {user?.role === "admin" && (
                <div className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-primary flex items-center justify-center">
                  <Shield className="h-3.5 w-3.5 text-primary-foreground" />
                </div>
              )}
            </div>
            <div className="text-center">
              <p className="font-bold text-lg">{user?.name || "Usuário"}</p>
              <p className="text-sm text-muted-foreground">{user?.email || "—"}</p>
            </div>
            <div className="flex flex-col gap-2 w-full">
              <Badge variant="outline" className={`justify-center gap-1.5 py-1.5 ${user?.role === "admin" ? "border-primary/30 text-primary" : ""}`}>
                {user?.role === "admin" ? <Shield className="h-3.5 w-3.5" /> : <User className="h-3.5 w-3.5" />}
                {user?.role === "admin" ? "Administrador" : "Usuário"}
              </Badge>
              {vip && (
                <Badge className={`justify-center gap-1.5 py-1.5 text-amber-400 bg-amber-400/10 border border-amber-400/20`}>
                  <Crown className="h-3.5 w-3.5" />
                  {vip.vipLevel.toUpperCase()} — {vip.keyLimit.toLocaleString()} keys
                </Badge>
              )}
            </div>
            <div className="w-full pt-2 border-t border-border/50 space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Membro desde</span>
                <span>{user?.createdAt ? new Date(user.createdAt).toLocaleDateString("pt-BR") : "—"}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Último acesso</span>
                <span>{user?.lastSignedIn ? new Date(user.lastSignedIn).toLocaleDateString("pt-BR") : "—"}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Edit Form */}
        <Card className="border-border/50 bg-card/50 lg:col-span-2">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <User className="h-4 w-4 text-primary" /> Editar Perfil
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-1.5">
              <Label>Nome de usuário</Label>
              <Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} placeholder="seu_username" />
            </div>
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5"><Globe className="h-3.5 w-3.5" /> Idioma</Label>
              <Select value={form.language} onValueChange={(v) => setForm({ ...form, language: v as "pt" | "en" })}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pt">🇧🇷 Português</SelectItem>
                  <SelectItem value="en">🇺🇸 English</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={() => updateMut.mutate({ username: form.username, language: form.language })}
              disabled={updateMut.isPending}
              className="gap-2"
            >
              {updateMut.isPending ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Salvar Alterações
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* My Devices */}
      <Card className="border-border/50 bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Smartphone className="h-4 w-4 text-primary" />
            Meus Dispositivos ({myDevices.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!myDevices.length ? (
            <p className="text-sm text-muted-foreground text-center py-6">Nenhum dispositivo registrado</p>
          ) : (
            <div className="space-y-2">
              {myDevices.map((device) => (
                <div key={device.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border/50">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-lg bg-muted/50 flex items-center justify-center">
                      <Smartphone className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{device.name || "Sem nome"}</p>
                      <p className="text-xs font-mono text-muted-foreground">{device.udid}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={`status-${device.status} text-xs`}>
                      {device.status === "online" ? "Online" : device.status === "banned" ? "Banido" : "Offline"}
                    </Badge>
                    {device.lastSeen && (
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {new Date(device.lastSeen).toLocaleDateString("pt-BR")}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Activity */}
      <Card className="border-border/50 bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Activity className="h-4 w-4 text-primary" />
            Histórico de Atividades
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {!activity?.length ? (
            <p className="text-sm text-muted-foreground text-center py-8">Nenhuma atividade registrada</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border/50 hover:bg-transparent">
                    <TableHead className="text-xs text-muted-foreground">Ação</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Detalhes</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Data</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activity.slice(0, 20).map((log) => (
                    <TableRow key={log.id} className="border-border/30 hover:bg-accent/20">
                      <TableCell className="text-sm">{actionLabels[log.action] ?? log.action}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{log.details || "—"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(log.createdAt).toLocaleString("pt-BR")}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
